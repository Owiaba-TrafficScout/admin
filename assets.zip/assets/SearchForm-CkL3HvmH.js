import{c as l}from"./PopoverContent.vue_vue_type_script_setup_true_lang-BW27N9MV.js";import{c as n}from"./App.vue_vue_type_script_setup_true_lang-DK6krLuU.js";import{o as m,g as p,b as c,a as r,u}from"./app-DsUbjtws.js";/**
 * @license lucide-vue-next v0.447.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=n("SearchIcon",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]),d={class:"flex w-full items-center px-4 py-3"},f={class:"relative w-full"},x={__name:"SearchForm",emits:["search"],setup(h,{emit:s}){const o=s,t=e=>{o("search",e.target.value)};return(e,a)=>(m(),p("form",d,[a[0]||(a[0]=c("label",{for:"",class:"sr-only"},"Search",-1)),c("div",f,[r(u(i),{class:"absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground"}),r(l,{type:"search",placeholder:"Search products...",class:"w-full appearance-none bg-background pl-8 shadow-none md:w-2/3 lg:w-1/3",onInput:t})])]))}};export{x as _};
