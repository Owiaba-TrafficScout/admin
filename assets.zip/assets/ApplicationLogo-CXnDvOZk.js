import{_ as o}from"./_plugin-vue_export-helper-DlAUqK2U.js";import{o as c,g as e}from"./app-DsUbjtws.js";const r={};function t(n,s){return c(),e("h1")}const p=o(r,[["render",t]]);export{p as A};
