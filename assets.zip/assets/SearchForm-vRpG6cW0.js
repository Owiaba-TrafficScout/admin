import{_ as n}from"./Input.vue_vue_type_script_setup_true_lang-15po9se3.js";import{c as l}from"./App.vue_vue_type_script_setup_true_lang-EWhZUm3s.js";import{o as i,g as m,b as e,a as c,u as p}from"./app-BlnEBNms.js";/**
 * @license lucide-vue-next v0.447.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _=l("SearchIcon",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]),f={class:"flex w-full items-center px-4 py-3"},h={class:"relative w-full"},u={class:"pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"},g={__name:"SearchForm",emits:["search"],setup(d,{emit:r}){const a=r,o=s=>{a("search",s.target.value)};return(s,t)=>(i(),m("form",f,[t[0]||(t[0]=e("label",{for:"",class:"sr-only"},"Search",-1)),e("div",h,[e("div",u,[c(p(_),{class:"h-4 w-4 text-muted-foreground"})]),c(n,{type:"search",placeholder:"Search...",class:"flex-1 bg-background pl-10 shadow-none",onInput:o})])]))}};export{g as _};
